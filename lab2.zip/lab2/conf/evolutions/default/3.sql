# --- Sample dataset

# --- !Ups
insert into employee (id,name, email) values (1, 'peter',  'petermarting@gmail.com');
insert into employee (id,name, email) values (2, 'Jimmy',  'jimhen@gmail.com');
insert into employee (id,name, email) values (3, 'Barry', 'breilly@gmail.com');